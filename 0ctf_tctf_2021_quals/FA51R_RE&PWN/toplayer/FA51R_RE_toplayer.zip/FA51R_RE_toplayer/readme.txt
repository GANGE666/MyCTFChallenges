# FA51R Re Challenge

Remote server: Ubuntu 18.04

The files in the directory `FA51R_RE` are not the full version running on the server, but these files are enough for you to solved this challenge and get the admin, RE flag, and the password of the FA51R_PWN attachment.

RUN

cd FA51R_RE/
./main