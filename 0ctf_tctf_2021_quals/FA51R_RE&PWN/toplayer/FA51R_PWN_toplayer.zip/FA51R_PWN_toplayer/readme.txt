# FA51R PWN Challenge

Remote server: Ubuntu 18.04

** Please solved FA51R RE first and get the password of `admin_files.zip`


RUN

cd FA51R_RE/
./main