#!/bin/sh
set -v on
systemctl stop ctfchallenge2021@fea
