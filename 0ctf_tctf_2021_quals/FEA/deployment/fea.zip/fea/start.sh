#!/bin/sh
set -v on
systemctl start ctfchallenge2021@fea
